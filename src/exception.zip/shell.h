// shell.h
// Copyright (c) 2024 Ishan Pranav
// Licensed under the MIT license.

#define SHELL_BUFFER_SIZE 4
