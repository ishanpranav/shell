// foreground_handler.c
// Copyright (c) 2024 Ishan Pranav
// Licensed under the MIT license.

#include "../handler.h"

bool foreground_handler(EULER_UNUSED Instruction instruction)
{
    return true;
}
